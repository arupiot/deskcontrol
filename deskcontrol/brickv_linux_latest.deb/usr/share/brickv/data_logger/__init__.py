# -*- coding: utf-8 -*-
"""
__init__.py: package initialization
data_logger

Roland Dudko
Marvin Lutz

"""
