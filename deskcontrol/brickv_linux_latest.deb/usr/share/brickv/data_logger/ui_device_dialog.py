# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/device_dialog.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_DeviceDialog(object):
    def setupUi(self, DeviceDialog):
        DeviceDialog.setObjectName(_fromUtf8("DeviceDialog"))
        DeviceDialog.setWindowModality(QtCore.Qt.WindowModal)
        DeviceDialog.resize(435, 471)
        self.verticalLayout = QtGui.QVBoxLayout(DeviceDialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.btn_add_device = QtGui.QPushButton(DeviceDialog)
        self.btn_add_device.setObjectName(_fromUtf8("btn_add_device"))
        self.gridLayout.addWidget(self.btn_add_device, 0, 0, 1, 1)
        self.tree_widget = QtGui.QTreeWidget(DeviceDialog)
        self.tree_widget.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
        self.tree_widget.setObjectName(_fromUtf8("tree_widget"))
        self.tree_widget.headerItem().setText(0, _fromUtf8("1"))
        self.tree_widget.header().setVisible(False)
        self.gridLayout.addWidget(self.tree_widget, 1, 0, 1, 4)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 0, 2, 1, 1)
        self.btn_close = QtGui.QPushButton(DeviceDialog)
        self.btn_close.setObjectName(_fromUtf8("btn_close"))
        self.gridLayout.addWidget(self.btn_close, 0, 3, 1, 1)
        self.btn_refresh = QtGui.QPushButton(DeviceDialog)
        self.btn_refresh.setObjectName(_fromUtf8("btn_refresh"))
        self.gridLayout.addWidget(self.btn_refresh, 0, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)

        self.retranslateUi(DeviceDialog)
        QtCore.QMetaObject.connectSlotsByName(DeviceDialog)
        DeviceDialog.setTabOrder(self.btn_add_device, self.btn_refresh)
        DeviceDialog.setTabOrder(self.btn_refresh, self.btn_close)
        DeviceDialog.setTabOrder(self.btn_close, self.tree_widget)

    def retranslateUi(self, DeviceDialog):
        DeviceDialog.setWindowTitle(_translate("DeviceDialog", "Add Device", None))
        self.btn_add_device.setText(_translate("DeviceDialog", "Add Device", None))
        self.btn_close.setText(_translate("DeviceDialog", "Close", None))
        self.btn_refresh.setText(_translate("DeviceDialog", "Refresh", None))

