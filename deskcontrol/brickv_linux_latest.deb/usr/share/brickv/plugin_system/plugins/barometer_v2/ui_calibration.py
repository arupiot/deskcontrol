# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/calibration.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Calibration(object):
    def setupUi(self, Calibration):
        Calibration.setObjectName(_fromUtf8("Calibration"))
        Calibration.resize(358, 380)
        self.verticalLayout_2 = QtGui.QVBoxLayout(Calibration)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_5 = QtGui.QLabel(Calibration)
        self.label_5.setTextFormat(QtCore.Qt.RichText)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout.addWidget(self.label_5, 7, 0, 1, 2)
        self.label_2 = QtGui.QLabel(Calibration)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.line_3 = QtGui.QFrame(Calibration)
        self.line_3.setFrameShape(QtGui.QFrame.HLine)
        self.line_3.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_3.setObjectName(_fromUtf8("line_3"))
        self.gridLayout.addWidget(self.line_3, 6, 0, 1, 2)
        self.label_6 = QtGui.QLabel(Calibration)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout.addWidget(self.label_6, 8, 0, 1, 1)
        self.lbl_a = QtGui.QLabel(Calibration)
        self.lbl_a.setObjectName(_fromUtf8("lbl_a"))
        self.gridLayout.addWidget(self.lbl_a, 1, 1, 1, 1)
        self.btn_cal_calibrate = QtGui.QPushButton(Calibration)
        self.btn_cal_calibrate.setObjectName(_fromUtf8("btn_cal_calibrate"))
        self.gridLayout.addWidget(self.btn_cal_calibrate, 9, 0, 1, 2)
        self.line = QtGui.QFrame(Calibration)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 3, 0, 1, 2)
        self.label_3 = QtGui.QLabel(Calibration)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 2, 0, 1, 1)
        self.lbl_t = QtGui.QLabel(Calibration)
        self.lbl_t.setObjectName(_fromUtf8("lbl_t"))
        self.gridLayout.addWidget(self.lbl_t, 2, 1, 1, 1)
        self.btn_cal_remove = QtGui.QPushButton(Calibration)
        self.btn_cal_remove.setObjectName(_fromUtf8("btn_cal_remove"))
        self.gridLayout.addWidget(self.btn_cal_remove, 5, 0, 1, 2)
        self.label = QtGui.QLabel(Calibration)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_4 = QtGui.QLabel(Calibration)
        self.label_4.setTextFormat(QtCore.Qt.RichText)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 4, 0, 1, 2)
        self.lbl_p = QtGui.QLabel(Calibration)
        self.lbl_p.setObjectName(_fromUtf8("lbl_p"))
        self.gridLayout.addWidget(self.lbl_p, 0, 1, 1, 1)
        self.sbox_cal_actual_air_pressure = QtGui.QDoubleSpinBox(Calibration)
        self.sbox_cal_actual_air_pressure.setDecimals(3)
        self.sbox_cal_actual_air_pressure.setMinimum(260.0)
        self.sbox_cal_actual_air_pressure.setMaximum(1260.0)
        self.sbox_cal_actual_air_pressure.setSingleStep(1.0)
        self.sbox_cal_actual_air_pressure.setProperty("value", 1013.25)
        self.sbox_cal_actual_air_pressure.setObjectName(_fromUtf8("sbox_cal_actual_air_pressure"))
        self.gridLayout.addWidget(self.sbox_cal_actual_air_pressure, 8, 1, 1, 1)
        self.verticalLayout_2.addLayout(self.gridLayout)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem)

        self.retranslateUi(Calibration)
        QtCore.QMetaObject.connectSlotsByName(Calibration)

    def retranslateUi(self, Calibration):
        Calibration.setWindowTitle(_translate("Calibration", "Barometer 2.0 Calibration", None))
        self.label_5.setText(_translate("Calibration", "<html><head/><body><p><span style=\" font-weight:600;\">Step 2:</span> Air pressure calibration.<br/><br/>A) Measure the air pressure with a precise barometer.</p><p><br/>B) Enter the measured air pressure below in mbar.</p><p><br/>C) Click &quot;Calibrate Air Pressure&quot;. </p></body></html>", None))
        self.label_2.setText(_translate("Calibration", "Altitude:", None))
        self.label_6.setText(_translate("Calibration", "Actual Air Pressure:", None))
        self.lbl_a.setText(_translate("Calibration", "0", None))
        self.btn_cal_calibrate.setText(_translate("Calibration", "Calibrate Air Pressure", None))
        self.label_3.setText(_translate("Calibration", "Temperature:", None))
        self.lbl_t.setText(_translate("Calibration", "0", None))
        self.btn_cal_remove.setText(_translate("Calibration", "Remove Old Calibration", None))
        self.label.setText(_translate("Calibration", "Air Pressure:", None))
        self.label_4.setText(_translate("Calibration", "<html><head/><body><p><span style=\" font-weight:600;\">Step 1:</span> To recalibrate the Bricklet you have to remove the old <br/>calibration.</p></body></html>", None))
        self.lbl_p.setText(_translate("Calibration", "0", None))
        self.sbox_cal_actual_air_pressure.setSuffix(_translate("Calibration", " mbar", None))

