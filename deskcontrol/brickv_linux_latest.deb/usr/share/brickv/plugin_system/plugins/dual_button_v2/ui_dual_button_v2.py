# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/dual_button_v2.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_DualButtonV2(object):
    def setupUi(self, DualButtonV2):
        DualButtonV2.setObjectName(_fromUtf8("DualButtonV2"))
        DualButtonV2.resize(407, 147)
        self.verticalLayout_6 = QtGui.QVBoxLayout(DualButtonV2)
        self.verticalLayout_6.setObjectName(_fromUtf8("verticalLayout_6"))
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_6.addItem(spacerItem)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.label_2 = QtGui.QLabel(DualButtonV2)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.verticalLayout_2.addWidget(self.label_2)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.label_4 = QtGui.QLabel(DualButtonV2)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.horizontalLayout_3.addWidget(self.label_4)
        self.label_status_button_l = QtGui.QLabel(DualButtonV2)
        self.label_status_button_l.setObjectName(_fromUtf8("label_status_button_l"))
        self.horizontalLayout_3.addWidget(self.label_status_button_l)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem2)
        self.verticalLayout_2.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName(_fromUtf8("horizontalLayout_5"))
        self.button_led_on_button_l = QtGui.QPushButton(DualButtonV2)
        self.button_led_on_button_l.setObjectName(_fromUtf8("button_led_on_button_l"))
        self.horizontalLayout_5.addWidget(self.button_led_on_button_l)
        self.button_led_off_button_l = QtGui.QPushButton(DualButtonV2)
        self.button_led_off_button_l.setObjectName(_fromUtf8("button_led_off_button_l"))
        self.horizontalLayout_5.addWidget(self.button_led_off_button_l)
        self.verticalLayout_2.addLayout(self.horizontalLayout_5)
        self.button_toggle_button_l = QtGui.QPushButton(DualButtonV2)
        self.button_toggle_button_l.setObjectName(_fromUtf8("button_toggle_button_l"))
        self.verticalLayout_2.addWidget(self.button_toggle_button_l)
        self.horizontalLayout.addLayout(self.verticalLayout_2)
        self.line = QtGui.QFrame(DualButtonV2)
        self.line.setFrameShape(QtGui.QFrame.VLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.horizontalLayout.addWidget(self.line)
        self.verticalLayout_3 = QtGui.QVBoxLayout()
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.label = QtGui.QLabel(DualButtonV2)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout_3.addWidget(self.label)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.label_3 = QtGui.QLabel(DualButtonV2)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.horizontalLayout_2.addWidget(self.label_3)
        self.label_status_button_r = QtGui.QLabel(DualButtonV2)
        self.label_status_button_r.setObjectName(_fromUtf8("label_status_button_r"))
        self.horizontalLayout_2.addWidget(self.label_status_button_r)
        spacerItem3 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem3)
        self.verticalLayout_3.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
        self.button_led_on_button_r = QtGui.QPushButton(DualButtonV2)
        self.button_led_on_button_r.setObjectName(_fromUtf8("button_led_on_button_r"))
        self.horizontalLayout_4.addWidget(self.button_led_on_button_r)
        self.button_led_off_button_r = QtGui.QPushButton(DualButtonV2)
        self.button_led_off_button_r.setObjectName(_fromUtf8("button_led_off_button_r"))
        self.horizontalLayout_4.addWidget(self.button_led_off_button_r)
        self.verticalLayout_3.addLayout(self.horizontalLayout_4)
        self.button_toggle_button_r = QtGui.QPushButton(DualButtonV2)
        self.button_toggle_button_r.setObjectName(_fromUtf8("button_toggle_button_r"))
        self.verticalLayout_3.addWidget(self.button_toggle_button_r)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        spacerItem4 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem4)
        self.verticalLayout_6.addLayout(self.horizontalLayout)
        spacerItem5 = QtGui.QSpacerItem(20, 0, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_6.addItem(spacerItem5)

        self.retranslateUi(DualButtonV2)
        QtCore.QMetaObject.connectSlotsByName(DualButtonV2)

    def retranslateUi(self, DualButtonV2):
        DualButtonV2.setWindowTitle(_translate("DualButtonV2", "Form", None))
        self.label_2.setText(_translate("DualButtonV2", "Button Left", None))
        self.label_4.setText(_translate("DualButtonV2", "Status:", None))
        self.label_status_button_l.setText(_translate("DualButtonV2", "Released, LED Off", None))
        self.button_led_on_button_l.setText(_translate("DualButtonV2", "LED On", None))
        self.button_led_off_button_l.setText(_translate("DualButtonV2", "LED Off", None))
        self.button_toggle_button_l.setText(_translate("DualButtonV2", "Auto Toggle", None))
        self.label.setText(_translate("DualButtonV2", "Button Right", None))
        self.label_3.setText(_translate("DualButtonV2", "Status:", None))
        self.label_status_button_r.setText(_translate("DualButtonV2", "Released, LED Off", None))
        self.button_led_on_button_r.setText(_translate("DualButtonV2", "LED On", None))
        self.button_led_off_button_r.setText(_translate("DualButtonV2", "LED Off", None))
        self.button_toggle_button_r.setText(_translate("DualButtonV2", "Auto Toggle", None))

