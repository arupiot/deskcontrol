# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/one_wire.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_OneWire(object):
    def setupUi(self, OneWire):
        OneWire.setObjectName(_fromUtf8("OneWire"))
        OneWire.resize(762, 437)
        self.verticalLayout = QtGui.QVBoxLayout(OneWire)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label = QtGui.QLabel(OneWire)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 5, 0, 1, 1)
        self.button_search = QtGui.QPushButton(OneWire)
        self.button_search.setObjectName(_fromUtf8("button_search"))
        self.gridLayout.addWidget(self.button_search, 1, 0, 1, 4)
        self.button_reset = QtGui.QPushButton(OneWire)
        self.button_reset.setObjectName(_fromUtf8("button_reset"))
        self.gridLayout.addWidget(self.button_reset, 0, 0, 1, 4)
        self.button_read_byte = QtGui.QPushButton(OneWire)
        self.button_read_byte.setObjectName(_fromUtf8("button_read_byte"))
        self.gridLayout.addWidget(self.button_read_byte, 4, 0, 1, 4)
        self.label_2 = QtGui.QLabel(OneWire)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 6, 0, 1, 1)
        self.spinbox_write_command = SpinBoxHex(OneWire)
        self.spinbox_write_command.setMaximum(255)
        self.spinbox_write_command.setObjectName(_fromUtf8("spinbox_write_command"))
        self.gridLayout.addWidget(self.spinbox_write_command, 5, 2, 1, 1)
        self.combo_box_write_command = QtGui.QComboBox(OneWire)
        self.combo_box_write_command.setObjectName(_fromUtf8("combo_box_write_command"))
        self.combo_box_write_command.addItem(_fromUtf8(""))
        self.gridLayout.addWidget(self.combo_box_write_command, 5, 1, 1, 1)
        self.button_write_byte = QtGui.QPushButton(OneWire)
        self.button_write_byte.setObjectName(_fromUtf8("button_write_byte"))
        self.gridLayout.addWidget(self.button_write_byte, 6, 3, 1, 1)
        self.button_write_command = QtGui.QPushButton(OneWire)
        self.button_write_command.setObjectName(_fromUtf8("button_write_command"))
        self.gridLayout.addWidget(self.button_write_command, 5, 3, 1, 1)
        self.spinbox_write_byte = SpinBoxHex(OneWire)
        self.spinbox_write_byte.setMaximum(255)
        self.spinbox_write_byte.setObjectName(_fromUtf8("spinbox_write_byte"))
        self.gridLayout.addWidget(self.spinbox_write_byte, 6, 1, 1, 2)
        self.verticalLayout.addLayout(self.gridLayout)
        self.tree_widget = QtGui.QTreeWidget(OneWire)
        self.tree_widget.setObjectName(_fromUtf8("tree_widget"))
        self.verticalLayout.addWidget(self.tree_widget)

        self.retranslateUi(OneWire)
        QtCore.QMetaObject.connectSlotsByName(OneWire)

    def retranslateUi(self, OneWire):
        OneWire.setWindowTitle(_translate("OneWire", "Form", None))
        self.label.setText(_translate("OneWire", "Write Comand:", None))
        self.button_search.setText(_translate("OneWire", "Search Bus", None))
        self.button_reset.setText(_translate("OneWire", "Reset Bus", None))
        self.button_read_byte.setText(_translate("OneWire", "Read Byte", None))
        self.label_2.setText(_translate("OneWire", "Write Byte:", None))
        self.combo_box_write_command.setItemText(0, _translate("OneWire", "Skip ID", None))
        self.button_write_byte.setText(_translate("OneWire", "Write", None))
        self.button_write_command.setText(_translate("OneWire", "Write", None))
        self.tree_widget.headerItem().setText(0, _translate("OneWire", "Time", None))
        self.tree_widget.headerItem().setText(1, _translate("OneWire", "Command", None))
        self.tree_widget.headerItem().setText(2, _translate("OneWire", "Value", None))
        self.tree_widget.headerItem().setText(3, _translate("OneWire", "Status", None))

from brickv.spin_box_hex import SpinBoxHex
