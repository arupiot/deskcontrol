# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/dmx.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_DMX(object):
    def setupUi(self, DMX):
        DMX.setObjectName(_fromUtf8("DMX"))
        DMX.resize(773, 753)
        self.verticalLayout = QtGui.QVBoxLayout(DMX)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label_3 = QtGui.QLabel(DMX)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.horizontalLayout.addWidget(self.label_3)
        self.mode_combobox = QtGui.QComboBox(DMX)
        self.mode_combobox.setObjectName(_fromUtf8("mode_combobox"))
        self.mode_combobox.addItem(_fromUtf8(""))
        self.mode_combobox.addItem(_fromUtf8(""))
        self.horizontalLayout.addWidget(self.mode_combobox)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.frame_duration_label = QtGui.QLabel(DMX)
        self.frame_duration_label.setObjectName(_fromUtf8("frame_duration_label"))
        self.horizontalLayout.addWidget(self.frame_duration_label)
        self.frame_duration_spinbox = QtGui.QSpinBox(DMX)
        self.frame_duration_spinbox.setMaximum(1000)
        self.frame_duration_spinbox.setProperty("value", 100)
        self.frame_duration_spinbox.setObjectName(_fromUtf8("frame_duration_spinbox"))
        self.horizontalLayout.addWidget(self.frame_duration_spinbox)
        self.frame_duration_unit = QtGui.QLabel(DMX)
        self.frame_duration_unit.setObjectName(_fromUtf8("frame_duration_unit"))
        self.horizontalLayout.addWidget(self.frame_duration_unit)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.address_table = QtGui.QTableWidget(DMX)
        self.address_table.setRowCount(512)
        self.address_table.setColumnCount(2)
        self.address_table.setObjectName(_fromUtf8("address_table"))
        item = QtGui.QTableWidgetItem()
        self.address_table.setVerticalHeaderItem(0, item)
        item = QtGui.QTableWidgetItem()
        self.address_table.setHorizontalHeaderItem(0, item)
        item = QtGui.QTableWidgetItem()
        self.address_table.setHorizontalHeaderItem(1, item)
        self.verticalLayout_2.addWidget(self.address_table)
        self.layout_dmx_overview = QtGui.QHBoxLayout()
        self.layout_dmx_overview.setObjectName(_fromUtf8("layout_dmx_overview"))
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.layout_dmx_overview.addItem(spacerItem1)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.layout_dmx_overview.addItem(spacerItem2)
        self.verticalLayout_2.addLayout(self.layout_dmx_overview)
        self.verticalLayout.addLayout(self.verticalLayout_2)

        self.retranslateUi(DMX)
        QtCore.QMetaObject.connectSlotsByName(DMX)

    def retranslateUi(self, DMX):
        DMX.setWindowTitle(_translate("DMX", "Form", None))
        self.label_3.setText(_translate("DMX", "DMX Mode:", None))
        self.mode_combobox.setItemText(0, _translate("DMX", "Master", None))
        self.mode_combobox.setItemText(1, _translate("DMX", "Slave", None))
        self.frame_duration_label.setText(_translate("DMX", "Frame Duration:", None))
        self.frame_duration_unit.setText(_translate("DMX", "ms", None))
        item = self.address_table.verticalHeaderItem(0)
        item.setText(_translate("DMX", "1", None))
        item = self.address_table.horizontalHeaderItem(0)
        item.setText(_translate("DMX", "Value", None))
        item = self.address_table.horizontalHeaderItem(1)
        item.setText(_translate("DMX", "Slider", None))

