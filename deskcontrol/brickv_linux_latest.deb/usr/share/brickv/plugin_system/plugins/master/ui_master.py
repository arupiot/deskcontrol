# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/master.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Master(object):
    def setupUi(self, Master):
        Master.setObjectName(_fromUtf8("Master"))
        Master.resize(796, 519)
        self.verticalLayout = QtGui.QVBoxLayout(Master)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.label_5 = QtGui.QLabel(Master)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.horizontalLayout.addWidget(self.label_5)
        self.stack_voltage_label = QtGui.QLabel(Master)
        self.stack_voltage_label.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.stack_voltage_label.setObjectName(_fromUtf8("stack_voltage_label"))
        self.horizontalLayout.addWidget(self.stack_voltage_label)
        spacerItem = QtGui.QSpacerItem(20, 1, QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.label_3 = QtGui.QLabel(Master)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.horizontalLayout.addWidget(self.label_3)
        self.stack_current_label = QtGui.QLabel(Master)
        self.stack_current_label.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.stack_current_label.setObjectName(_fromUtf8("stack_current_label"))
        self.horizontalLayout.addWidget(self.stack_current_label)
        spacerItem1 = QtGui.QSpacerItem(1, 1, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.label_2 = QtGui.QLabel(Master)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.horizontalLayout.addWidget(self.label_2)
        self.extension_label = QtGui.QLabel(Master)
        self.extension_label.setObjectName(_fromUtf8("extension_label"))
        self.horizontalLayout.addWidget(self.extension_label)
        self.extension_type_button = QtGui.QPushButton(Master)
        self.extension_type_button.setObjectName(_fromUtf8("extension_type_button"))
        self.horizontalLayout.addWidget(self.extension_type_button)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.label_no_extension = QtGui.QLabel(Master)
        self.label_no_extension.setAlignment(QtCore.Qt.AlignCenter)
        self.label_no_extension.setObjectName(_fromUtf8("label_no_extension"))
        self.verticalLayout.addWidget(self.label_no_extension)
        self.tab_widget = QtGui.QTabWidget(Master)
        self.tab_widget.setTabPosition(QtGui.QTabWidget.West)
        self.tab_widget.setObjectName(_fromUtf8("tab_widget"))
        self.tab = QtGui.QWidget()
        self.tab.setObjectName(_fromUtf8("tab"))
        self.tab_widget.addTab(self.tab, _fromUtf8(""))
        self.verticalLayout.addWidget(self.tab_widget)

        self.retranslateUi(Master)
        self.tab_widget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Master)

    def retranslateUi(self, Master):
        Master.setWindowTitle(_translate("Master", "Form", None))
        self.label_5.setText(_translate("Master", "Stack Voltage:", None))
        self.stack_voltage_label.setText(_translate("Master", "0 V", None))
        self.label_3.setText(_translate("Master", "Stack Current:", None))
        self.stack_current_label.setText(_translate("Master", "0 mA", None))
        self.label_2.setText(_translate("Master", "Extensions:", None))
        self.extension_label.setText(_translate("Master", "None Present", None))
        self.extension_type_button.setText(_translate("Master", "Configure", None))
        self.label_no_extension.setText(_translate("Master", "Could not find any Master Extensions on Master Brick stack.", None))
        self.tab_widget.setTabText(self.tab_widget.indexOf(self.tab), _translate("Master", "dummy", None))

