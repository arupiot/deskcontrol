# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/calibrate_gyroscope_gain.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_calibrate_gyroscope_gain(object):
    def setupUi(self, calibrate_gyroscope_gain):
        calibrate_gyroscope_gain.setObjectName(_fromUtf8("calibrate_gyroscope_gain"))
        calibrate_gyroscope_gain.resize(329, 260)
        self.verticalLayout = QtGui.QVBoxLayout(calibrate_gyroscope_gain)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.vlayout = QtGui.QVBoxLayout()
        self.vlayout.setObjectName(_fromUtf8("vlayout"))
        self.grid_layout = QtGui.QGridLayout()
        self.grid_layout.setObjectName(_fromUtf8("grid_layout"))
        self.label = QtGui.QLabel(calibrate_gyroscope_gain)
        self.label.setObjectName(_fromUtf8("label"))
        self.grid_layout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(calibrate_gyroscope_gain)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.grid_layout.addWidget(self.label_2, 0, 1, 1, 1)
        self.label_3 = QtGui.QLabel(calibrate_gyroscope_gain)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.grid_layout.addWidget(self.label_3, 0, 2, 1, 1)
        self.label_4 = QtGui.QLabel(calibrate_gyroscope_gain)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.grid_layout.addWidget(self.label_4, 0, 3, 1, 1)
        self.label_5 = QtGui.QLabel(calibrate_gyroscope_gain)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.grid_layout.addWidget(self.label_5, 1, 0, 1, 1)
        self.gain_x = QtGui.QLabel(calibrate_gyroscope_gain)
        self.gain_x.setObjectName(_fromUtf8("gain_x"))
        self.grid_layout.addWidget(self.gain_x, 1, 1, 1, 1)
        self.gain_y = QtGui.QLabel(calibrate_gyroscope_gain)
        self.gain_y.setObjectName(_fromUtf8("gain_y"))
        self.grid_layout.addWidget(self.gain_y, 1, 2, 1, 1)
        self.gain_z = QtGui.QLabel(calibrate_gyroscope_gain)
        self.gain_z.setObjectName(_fromUtf8("gain_z"))
        self.grid_layout.addWidget(self.gain_z, 1, 3, 1, 1)
        self.vlayout.addLayout(self.grid_layout)
        self.start_button = QtGui.QPushButton(calibrate_gyroscope_gain)
        self.start_button.setObjectName(_fromUtf8("start_button"))
        self.vlayout.addWidget(self.start_button)
        self.text_label = QtGui.QLabel(calibrate_gyroscope_gain)
        self.text_label.setWordWrap(True)
        self.text_label.setObjectName(_fromUtf8("text_label"))
        self.vlayout.addWidget(self.text_label)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.vlayout.addItem(spacerItem)
        self.verticalLayout.addLayout(self.vlayout)

        self.retranslateUi(calibrate_gyroscope_gain)
        QtCore.QMetaObject.connectSlotsByName(calibrate_gyroscope_gain)

    def retranslateUi(self, calibrate_gyroscope_gain):
        calibrate_gyroscope_gain.setWindowTitle(_translate("calibrate_gyroscope_gain", "Form", None))
        self.label.setText(_translate("calibrate_gyroscope_gain", "Type", None))
        self.label_2.setText(_translate("calibrate_gyroscope_gain", "X", None))
        self.label_3.setText(_translate("calibrate_gyroscope_gain", "Y", None))
        self.label_4.setText(_translate("calibrate_gyroscope_gain", "Z", None))
        self.label_5.setText(_translate("calibrate_gyroscope_gain", "Gain", None))
        self.gain_x.setText(_translate("calibrate_gyroscope_gain", "?", None))
        self.gain_y.setText(_translate("calibrate_gyroscope_gain", "?", None))
        self.gain_z.setText(_translate("calibrate_gyroscope_gain", "?", None))
        self.start_button.setText(_translate("calibrate_gyroscope_gain", "Start Calibration", None))
        self.text_label.setText(_translate("calibrate_gyroscope_gain", "Text", None))

