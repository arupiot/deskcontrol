# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/calibrate_import_export.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_calibrate_import_export(object):
    def setupUi(self, calibrate_import_export):
        calibrate_import_export.setObjectName(_fromUtf8("calibrate_import_export"))
        calibrate_import_export.resize(329, 139)
        self.verticalLayout = QtGui.QVBoxLayout(calibrate_import_export)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.restore_button = QtGui.QPushButton(calibrate_import_export)
        self.restore_button.setObjectName(_fromUtf8("restore_button"))
        self.verticalLayout.addWidget(self.restore_button)
        self.line = QtGui.QFrame(calibrate_import_export)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.verticalLayout.addWidget(self.line)
        self.vlayout = QtGui.QVBoxLayout()
        self.vlayout.setObjectName(_fromUtf8("vlayout"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.export_button = QtGui.QPushButton(calibrate_import_export)
        self.export_button.setEnabled(True)
        self.export_button.setFlat(False)
        self.export_button.setObjectName(_fromUtf8("export_button"))
        self.horizontalLayout_2.addWidget(self.export_button)
        self.import_button = QtGui.QPushButton(calibrate_import_export)
        self.import_button.setObjectName(_fromUtf8("import_button"))
        self.horizontalLayout_2.addWidget(self.import_button)
        self.vlayout.addLayout(self.horizontalLayout_2)
        self.verticalLayout.addLayout(self.vlayout)
        self.text_edit = QtGui.QPlainTextEdit(calibrate_import_export)
        self.text_edit.setObjectName(_fromUtf8("text_edit"))
        self.verticalLayout.addWidget(self.text_edit)

        self.retranslateUi(calibrate_import_export)
        QtCore.QMetaObject.connectSlotsByName(calibrate_import_export)

    def retranslateUi(self, calibrate_import_export):
        calibrate_import_export.setWindowTitle(_translate("calibrate_import_export", "Form", None))
        self.restore_button.setText(_translate("calibrate_import_export", "Restore Factory Calibration", None))
        self.export_button.setText(_translate("calibrate_import_export", "Export", None))
        self.import_button.setText(_translate("calibrate_import_export", "Import", None))

