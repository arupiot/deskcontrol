# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/calibrate_gyroscope_bias.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_calibrate_gyroscope_bias(object):
    def setupUi(self, calibrate_gyroscope_bias):
        calibrate_gyroscope_bias.setObjectName(_fromUtf8("calibrate_gyroscope_bias"))
        calibrate_gyroscope_bias.resize(329, 260)
        self.verticalLayout = QtGui.QVBoxLayout(calibrate_gyroscope_bias)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.vlayout = QtGui.QVBoxLayout()
        self.vlayout.setObjectName(_fromUtf8("vlayout"))
        self.grid_layout = QtGui.QGridLayout()
        self.grid_layout.setObjectName(_fromUtf8("grid_layout"))
        self.label = QtGui.QLabel(calibrate_gyroscope_bias)
        self.label.setObjectName(_fromUtf8("label"))
        self.grid_layout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(calibrate_gyroscope_bias)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.grid_layout.addWidget(self.label_2, 0, 1, 1, 1)
        self.label_3 = QtGui.QLabel(calibrate_gyroscope_bias)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.grid_layout.addWidget(self.label_3, 0, 2, 1, 1)
        self.label_4 = QtGui.QLabel(calibrate_gyroscope_bias)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.grid_layout.addWidget(self.label_4, 0, 3, 1, 1)
        self.label_6 = QtGui.QLabel(calibrate_gyroscope_bias)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.grid_layout.addWidget(self.label_6, 1, 0, 1, 1)
        self.bias_low_x = QtGui.QLabel(calibrate_gyroscope_bias)
        self.bias_low_x.setObjectName(_fromUtf8("bias_low_x"))
        self.grid_layout.addWidget(self.bias_low_x, 1, 1, 1, 1)
        self.bias_low_y = QtGui.QLabel(calibrate_gyroscope_bias)
        self.bias_low_y.setObjectName(_fromUtf8("bias_low_y"))
        self.grid_layout.addWidget(self.bias_low_y, 1, 2, 1, 1)
        self.bias_low_z = QtGui.QLabel(calibrate_gyroscope_bias)
        self.bias_low_z.setObjectName(_fromUtf8("bias_low_z"))
        self.grid_layout.addWidget(self.bias_low_z, 1, 3, 1, 1)
        self.label_5 = QtGui.QLabel(calibrate_gyroscope_bias)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.grid_layout.addWidget(self.label_5, 0, 4, 1, 1)
        self.t_low = QtGui.QLabel(calibrate_gyroscope_bias)
        self.t_low.setObjectName(_fromUtf8("t_low"))
        self.grid_layout.addWidget(self.t_low, 1, 4, 1, 1)
        self.label_7 = QtGui.QLabel(calibrate_gyroscope_bias)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.grid_layout.addWidget(self.label_7, 2, 0, 1, 1)
        self.bias_high_x = QtGui.QLabel(calibrate_gyroscope_bias)
        self.bias_high_x.setObjectName(_fromUtf8("bias_high_x"))
        self.grid_layout.addWidget(self.bias_high_x, 2, 1, 1, 1)
        self.bias_high_y = QtGui.QLabel(calibrate_gyroscope_bias)
        self.bias_high_y.setObjectName(_fromUtf8("bias_high_y"))
        self.grid_layout.addWidget(self.bias_high_y, 2, 2, 1, 1)
        self.bias_high_z = QtGui.QLabel(calibrate_gyroscope_bias)
        self.bias_high_z.setObjectName(_fromUtf8("bias_high_z"))
        self.grid_layout.addWidget(self.bias_high_z, 2, 3, 1, 1)
        self.t_high = QtGui.QLabel(calibrate_gyroscope_bias)
        self.t_high.setObjectName(_fromUtf8("t_high"))
        self.grid_layout.addWidget(self.t_high, 2, 4, 1, 1)
        self.vlayout.addLayout(self.grid_layout)
        self.start_button = QtGui.QPushButton(calibrate_gyroscope_bias)
        self.start_button.setObjectName(_fromUtf8("start_button"))
        self.vlayout.addWidget(self.start_button)
        self.text_label = QtGui.QLabel(calibrate_gyroscope_bias)
        self.text_label.setWordWrap(True)
        self.text_label.setObjectName(_fromUtf8("text_label"))
        self.vlayout.addWidget(self.text_label)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.vlayout.addItem(spacerItem)
        self.verticalLayout.addLayout(self.vlayout)

        self.retranslateUi(calibrate_gyroscope_bias)
        QtCore.QMetaObject.connectSlotsByName(calibrate_gyroscope_bias)

    def retranslateUi(self, calibrate_gyroscope_bias):
        calibrate_gyroscope_bias.setWindowTitle(_translate("calibrate_gyroscope_bias", "Form", None))
        self.label.setText(_translate("calibrate_gyroscope_bias", "Type", None))
        self.label_2.setText(_translate("calibrate_gyroscope_bias", "X", None))
        self.label_3.setText(_translate("calibrate_gyroscope_bias", "Y", None))
        self.label_4.setText(_translate("calibrate_gyroscope_bias", "Z", None))
        self.label_6.setText(_translate("calibrate_gyroscope_bias", "Bias Low", None))
        self.bias_low_x.setText(_translate("calibrate_gyroscope_bias", "?", None))
        self.bias_low_y.setText(_translate("calibrate_gyroscope_bias", "?", None))
        self.bias_low_z.setText(_translate("calibrate_gyroscope_bias", "?", None))
        self.label_5.setText(_translate("calibrate_gyroscope_bias", "Temperature", None))
        self.t_low.setText(_translate("calibrate_gyroscope_bias", "?", None))
        self.label_7.setText(_translate("calibrate_gyroscope_bias", "Bias High", None))
        self.bias_high_x.setText(_translate("calibrate_gyroscope_bias", "?", None))
        self.bias_high_y.setText(_translate("calibrate_gyroscope_bias", "?", None))
        self.bias_high_z.setText(_translate("calibrate_gyroscope_bias", "?", None))
        self.t_high.setText(_translate("calibrate_gyroscope_bias", "?", None))
        self.start_button.setText(_translate("calibrate_gyroscope_bias", "Start Calibration Low", None))
        self.text_label.setText(_translate("calibrate_gyroscope_bias", "Text", None))

