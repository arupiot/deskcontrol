# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/dual_button.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_DualButton(object):
    def setupUi(self, DualButton):
        DualButton.setObjectName(_fromUtf8("DualButton"))
        DualButton.resize(596, 240)
        self.verticalLayout_6 = QtGui.QVBoxLayout(DualButton)
        self.verticalLayout_6.setObjectName(_fromUtf8("verticalLayout_6"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.label_2 = QtGui.QLabel(DualButton)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.verticalLayout_2.addWidget(self.label_2)
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.label_4 = QtGui.QLabel(DualButton)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.horizontalLayout_3.addWidget(self.label_4)
        self.label_status_button_l = QtGui.QLabel(DualButton)
        self.label_status_button_l.setObjectName(_fromUtf8("label_status_button_l"))
        self.horizontalLayout_3.addWidget(self.label_status_button_l)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem)
        self.verticalLayout_2.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_5 = QtGui.QHBoxLayout()
        self.horizontalLayout_5.setObjectName(_fromUtf8("horizontalLayout_5"))
        self.button_led_on_button_l = QtGui.QPushButton(DualButton)
        self.button_led_on_button_l.setObjectName(_fromUtf8("button_led_on_button_l"))
        self.horizontalLayout_5.addWidget(self.button_led_on_button_l)
        self.button_led_off_button_l = QtGui.QPushButton(DualButton)
        self.button_led_off_button_l.setObjectName(_fromUtf8("button_led_off_button_l"))
        self.horizontalLayout_5.addWidget(self.button_led_off_button_l)
        self.verticalLayout_2.addLayout(self.horizontalLayout_5)
        self.button_toggle_button_l = QtGui.QPushButton(DualButton)
        self.button_toggle_button_l.setObjectName(_fromUtf8("button_toggle_button_l"))
        self.verticalLayout_2.addWidget(self.button_toggle_button_l)
        self.horizontalLayout.addLayout(self.verticalLayout_2)
        self.line = QtGui.QFrame(DualButton)
        self.line.setFrameShape(QtGui.QFrame.VLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.horizontalLayout.addWidget(self.line)
        self.verticalLayout_3 = QtGui.QVBoxLayout()
        self.verticalLayout_3.setObjectName(_fromUtf8("verticalLayout_3"))
        self.label = QtGui.QLabel(DualButton)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout_3.addWidget(self.label)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.label_3 = QtGui.QLabel(DualButton)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.horizontalLayout_2.addWidget(self.label_3)
        self.label_status_button_r = QtGui.QLabel(DualButton)
        self.label_status_button_r.setObjectName(_fromUtf8("label_status_button_r"))
        self.horizontalLayout_2.addWidget(self.label_status_button_r)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem1)
        self.verticalLayout_3.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_4 = QtGui.QHBoxLayout()
        self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
        self.button_led_on_button_r = QtGui.QPushButton(DualButton)
        self.button_led_on_button_r.setObjectName(_fromUtf8("button_led_on_button_r"))
        self.horizontalLayout_4.addWidget(self.button_led_on_button_r)
        self.button_led_off_button_r = QtGui.QPushButton(DualButton)
        self.button_led_off_button_r.setObjectName(_fromUtf8("button_led_off_button_r"))
        self.horizontalLayout_4.addWidget(self.button_led_off_button_r)
        self.verticalLayout_3.addLayout(self.horizontalLayout_4)
        self.button_toggle_button_r = QtGui.QPushButton(DualButton)
        self.button_toggle_button_r.setObjectName(_fromUtf8("button_toggle_button_r"))
        self.verticalLayout_3.addWidget(self.button_toggle_button_r)
        self.horizontalLayout.addLayout(self.verticalLayout_3)
        self.verticalLayout_6.addLayout(self.horizontalLayout)
        spacerItem2 = QtGui.QSpacerItem(20, 0, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_6.addItem(spacerItem2)

        self.retranslateUi(DualButton)
        QtCore.QMetaObject.connectSlotsByName(DualButton)

    def retranslateUi(self, DualButton):
        DualButton.setWindowTitle(_translate("DualButton", "Form", None))
        self.label_2.setText(_translate("DualButton", "Button L", None))
        self.label_4.setText(_translate("DualButton", "Status:", None))
        self.label_status_button_l.setText(_translate("DualButton", "Released, LED Off", None))
        self.button_led_on_button_l.setText(_translate("DualButton", "LED On", None))
        self.button_led_off_button_l.setText(_translate("DualButton", "LED Off", None))
        self.button_toggle_button_l.setText(_translate("DualButton", "Auto Toggle", None))
        self.label.setText(_translate("DualButton", "Button R", None))
        self.label_3.setText(_translate("DualButton", "Status:", None))
        self.label_status_button_r.setText(_translate("DualButton", "Released, LED Off", None))
        self.button_led_on_button_r.setText(_translate("DualButton", "LED On", None))
        self.button_led_off_button_r.setText(_translate("DualButton", "LED Off", None))
        self.button_toggle_button_r.setText(_translate("DualButton", "Auto Toggle", None))

