# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/analog_out_v3.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_AnalogOutV3(object):
    def setupUi(self, AnalogOutV3):
        AnalogOutV3.setObjectName(_fromUtf8("AnalogOutV3"))
        AnalogOutV3.resize(718, 494)
        self.verticalLayout = QtGui.QVBoxLayout(AnalogOutV3)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.input_voltage_desc_label = QtGui.QLabel(AnalogOutV3)
        self.input_voltage_desc_label.setObjectName(_fromUtf8("input_voltage_desc_label"))
        self.gridLayout.addWidget(self.input_voltage_desc_label, 0, 0, 1, 1)
        self.output_voltage_label = QtGui.QLabel(AnalogOutV3)
        self.output_voltage_label.setObjectName(_fromUtf8("output_voltage_label"))
        self.gridLayout.addWidget(self.output_voltage_label, 1, 0, 1, 1)
        self.input_voltage_label = QtGui.QLabel(AnalogOutV3)
        self.input_voltage_label.setObjectName(_fromUtf8("input_voltage_label"))
        self.gridLayout.addWidget(self.input_voltage_label, 0, 1, 1, 1)
        self.output_voltage_box = QtGui.QDoubleSpinBox(AnalogOutV3)
        self.output_voltage_box.setDecimals(3)
        self.output_voltage_box.setMaximum(12.0)
        self.output_voltage_box.setSingleStep(0.1)
        self.output_voltage_box.setObjectName(_fromUtf8("output_voltage_box"))
        self.gridLayout.addWidget(self.output_voltage_box, 1, 1, 1, 1)
        self.horizontalLayout.addLayout(self.gridLayout)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.verticalLayout.addLayout(self.horizontalLayout)
        spacerItem3 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem3)

        self.retranslateUi(AnalogOutV3)
        QtCore.QMetaObject.connectSlotsByName(AnalogOutV3)

    def retranslateUi(self, AnalogOutV3):
        AnalogOutV3.setWindowTitle(_translate("AnalogOutV3", "Form", None))
        self.input_voltage_desc_label.setText(_translate("AnalogOutV3", "Input Voltage:", None))
        self.output_voltage_label.setText(_translate("AnalogOutV3", "Output Voltage:", None))
        self.input_voltage_label.setText(_translate("AnalogOutV3", "TBD V", None))
        self.output_voltage_box.setSuffix(_translate("AnalogOutV3", " V", None))

