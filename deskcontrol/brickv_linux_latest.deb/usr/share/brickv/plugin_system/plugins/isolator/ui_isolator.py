# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/isolator.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Isolator(object):
    def setupUi(self, Isolator):
        Isolator.setObjectName(_fromUtf8("Isolator"))
        Isolator.resize(668, 537)
        self.verticalLayout = QtGui.QVBoxLayout(Isolator)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout_5 = QtGui.QGridLayout()
        self.gridLayout_5.setObjectName(_fromUtf8("gridLayout_5"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout_5.addItem(spacerItem, 2, 4, 1, 1)
        spacerItem1 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout_5.addItem(spacerItem1, 0, 1, 1, 1)
        self.label = QtGui.QLabel(Isolator)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout_5.addWidget(self.label, 1, 1, 1, 1)
        self.label_messages_from_brick = QtGui.QLabel(Isolator)
        self.label_messages_from_brick.setObjectName(_fromUtf8("label_messages_from_brick"))
        self.gridLayout_5.addWidget(self.label_messages_from_brick, 1, 2, 1, 2)
        self.label_2 = QtGui.QLabel(Isolator)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout_5.addWidget(self.label_2, 2, 1, 1, 1)
        spacerItem2 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout_5.addItem(spacerItem2, 2, 0, 1, 1)
        self.label_isolated_bricklet = QtGui.QLabel(Isolator)
        self.label_isolated_bricklet.setObjectName(_fromUtf8("label_isolated_bricklet"))
        self.gridLayout_5.addWidget(self.label_isolated_bricklet, 3, 2, 1, 1)
        self.label_messages_from_bricklet = QtGui.QLabel(Isolator)
        self.label_messages_from_bricklet.setObjectName(_fromUtf8("label_messages_from_bricklet"))
        self.gridLayout_5.addWidget(self.label_messages_from_bricklet, 2, 2, 1, 2)
        self.label_3 = QtGui.QLabel(Isolator)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout_5.addWidget(self.label_3, 3, 1, 1, 1)
        self.button_bricklet = QtGui.QPushButton(Isolator)
        self.button_bricklet.setObjectName(_fromUtf8("button_bricklet"))
        self.gridLayout_5.addWidget(self.button_bricklet, 4, 1, 1, 2)
        self.verticalLayout.addLayout(self.gridLayout_5)
        spacerItem3 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem3)

        self.retranslateUi(Isolator)
        QtCore.QMetaObject.connectSlotsByName(Isolator)

    def retranslateUi(self, Isolator):
        Isolator.setWindowTitle(_translate("Isolator", "Form", None))
        self.label.setText(_translate("Isolator", "Messages from Brick to Bricklet:", None))
        self.label_messages_from_brick.setText(_translate("Isolator", "TBD", None))
        self.label_2.setText(_translate("Isolator", "Messages from Bricklet to Brick:", None))
        self.label_isolated_bricklet.setText(_translate("Isolator", "TBD", None))
        self.label_messages_from_bricklet.setText(_translate("Isolator", "TBD", None))
        self.label_3.setText(_translate("Isolator", "Isolated Bricklet:", None))
        self.button_bricklet.setText(_translate("Isolator", "Open Bricklet", None))

